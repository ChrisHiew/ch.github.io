function setup() {
    createCanvas(900, 600);
    background(0);
}

function draw() {

}
